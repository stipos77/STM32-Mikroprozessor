/*
 * Abgegeben von: Steven Atmodjo
 * Mat. Nr. 772550
 *
 */

#include "mbed.h"

#include "breadboard.h"
#include "CPolledTimer.h"
#include "CDebouncer.h"

// Legen Sie die globalen Objekte, die die Peripheriekomponenten

// repräsentieren, hier an (vor den Funktionen).

BusOut leds(BB_LED_7, BB_LED_6, BB_LED_5, BB_LED_4, BB_LED_3, BB_LED_2,
BB_LED_1, BB_LED_0);

BusIn keys(BB_BTN_7, BB_BTN_6, BB_BTN_5, BB_BTN_4, BB_BTN_3, BB_BTN_2, BB_BTN_1,
BB_BTN_0);

// DigitalOut led1(LED1);

/**
 * Implementierung der Lösung zur Aufgabe 1.
 */
void task1() {
	/* Löschen Sie diesen Kommentar, nachdem Sie ihn zur Kenntnis genommen
	 * haben:
	 *
	 * Beachten Sie, dass in Mikrocontroller-Programmen die main-Methode
	 * nie beendet werden darf, denn es gibt keinen "Desktop" o.ä. zu dem
	 * nach der Ausführung zurückgekehrt werden könnte. Außerdem würden die
	 * Destruktoren der globalen Objekte aufgerufen, d.h. es würde nichts
	 * mehr funktionieren.
	 *
	 * Der Code, den Sie ausführen möchten, steht also entweder vor einer
	 * Endlosschleife (wenn er nur einmal ausgeführt werden soll) oder in
	 * einer Endlosschleife, wenn er immer wieder ausgeführt werden soll.
	 *
	 * Die Endlosschleife bedindet sich normalerweise in der main-Funktion.
	 * Da hier im Labor verschiedene Aufgaben bearbeitet werden sollen,
	 * wird die Endlosschleife in Funktionen task1(), task2(), ...
	 * implementiert und in main() jeweils eine dieser Funktionen aufgerufen.
	 *
	 * Welche Implementierung gerade aktiv ist, "steuern" Sie durch den
	 * entsprechenden Aufruf in main(). Kommentieren Sie keine der Funktionen
	 * task1(), task2(), ... aus! In diesem Fall würde bei der Kontrolle
	 * Ihrer Abgabe der Code nicht übersetzt und damit nicht auf
	 * Korrektheit überprüft. Auskommentieren einer der Funktionen task1(),
	 * task2(), ... führt zu einer "gelben Karte".
	 */

	// Schreiben Sie vor der Enlosschleife den einmal auszuführenden Code
	//task1 schaltet alle leds ein (1111 1111) und aus (0000 0000) jede 100 ms
	while (true) {
		// Schreiben Sie in der Endlosschleife den immer wieder auszuführenden
		// Code

		//Binaerwert des leds : 1111 1111

		leds = 0xFF;

		//verzögert für 100 ms das Durchführen des Codes im nächsten Zeile

		thread_sleep_for(100);

		//leds auf 0000 0000 setzen

		leds = 0x00;

		//nochmal für 100 ms der nächsten dürchzuführende Code verzögern

		thread_sleep_for(100);

	}
}

//task 2 schaltet leds ein entsprechend Druck des Tasters

void task2() {

	while (true) {

		//Binärwert des leds entspricht Binärwert des Tasters

		leds = keys.read();

	}
}

//task 3 toggles the leds according to the press of the keys

void task3() {

	//Reading the state of keys before pressing anything and assigning the value
	//(0000 0000) of the keys to a previousKeyStates

	uint8_t previousKeyStates = keys.read();

	while (true) {

		//Reading the state of the keys after pressing and assigning the value
		//to a variable

		uint8_t newKeyStates = keys.read();

		// LED is toggled only when newKeyStates has a 1 in the same place where
		// previousKeyStates has a 0. "~previousKeyStates" is used so that
		// LED is toggled only when a corresponding key has been pressed

		leds = leds ^ (newKeyStates & (~previousKeyStates));

		//assigning current newKeyStates to previousKeyStates for further
		//use of the program

		previousKeyStates = newKeyStates;

	}

}

//task 4 toggles the leds exactly like task 3, but with a debouncer which delays the
//reading of keys

void task4() {

//creating an object newDebouncer of  type CDebouncer with a time delay of 250ms

	CDebouncer newDebouncer(&keys, 250);

	//Reading the state of keys before pressing anything and assigning the value
	//(0000 0000) of the keys to a previousKeyStates

	uint8_t previousKeyStates = newDebouncer.read();

	while (true) {

		//reading key inputs using the int() operator of class CDebouncer
		//which returns the read() method of this class

		uint8_t newKeyStates = newDebouncer;

		// LED is toggled only when newKeyStates has a 1 in the same place where
		// previousKeyStates has a 0. "~previousKeyStates" is used so that
		// LED is toggled only when a corresponding key has been pressed

		leds = leds ^ (newKeyStates & ~previousKeyStates);

		//assigning current newKeyStates to previousKeyStates for further
		//use of the program

		previousKeyStates = newKeyStates;
	}

}

//task5 shifts the LED light to the left every 1000 ms using thread_sleep_for

void task5() {

	//initializing the leds (first light is at furthest right side)

	leds = 1;

	while (true) {

		//thread_sleep_for pauses the execution of following code by 1000ms

		thread_sleep_for(1000);

		//shifts LED to the left by 1

		leds = leds << 1;

		//has the LED been shifted to the furthest left side?

		if (leds == 0) {

			//LED has been shifted to the furthest left side, as a result it's
			//set to the furthest right side again (by way of changing the binary)

			leds = 1;
		}
	}
}

//task6 shifts the LED light to the left every 1000 ms using a self made timer

void task6() {

	//amount of time delay (1000 ms)

	int64_t waitTime = 1000;

	//targetTime is equal to waitTime + current time

	int64_t targetTime = waitTime + std::chrono::duration_cast
			< std::chrono::milliseconds
			> (HighResClock::now().time_since_epoch()).count();

	//initializing leds (first light is at furthest right side)

	leds = 1;

	while (true) {

		//If current time is later than targetTime

		if (std::chrono::duration_cast < std::chrono::milliseconds
				> (HighResClock::now().time_since_epoch()).count()
				>= targetTime) {

			//LED is shifted once to the left

			leds = leds << 1;

			//targetTime is updated

			targetTime += waitTime;

			//if LED has been shifted to furthest left side

			if (leds == 0) {

				//LED has been shifted to the furthest left side, as a result it's
				//set to the furthest right side again (by way of changing the binary)

				leds = 1;
			}

		}
	}

}

/**
 * Siehe Versuchsdurchführung.
 // */

//task7 shows different frequencies through the blinking of leds by creating
//objects (timers) of class type CPolledTimer
void task7() {

	//creating the object "twoHz" of class type CPolledTimer in order to represent
	//2 Hz (1 s/ 500 ms = 2 Hz)

	CPolledTimer twoHz(500);

	//creating the object "threeHz" of class type CPolledTimer in order to represent
	//3 Hz (1 s/ 333 ms = 3 Hz)

	CPolledTimer threeHz(333);

	//creating the object "fourHz" of class type CPolledTimer in order to represent
	//4 Hz (1 s/ 250 ms = 4 Hz)

	CPolledTimer fourHz(250);

	while (true) {

		//If two Hz has been reached

		if (twoHz.timeReached()) {

			//furthest right LED blinks

			leds = leds ^ (1 << 0);
		}

		//If three Hz has been reached

		if (threeHz.timeReached()) {

			//LED shifted by 1 to the left blinks

			leds = leds ^ (1 << 1);
		}

		//If four Hz has been reached

		if (fourHz.timeReached()) {

			//LED shifted by 2 to the left blinks

			leds = leds ^ (1 << 2);
		}
	}
}

//task8 performs the same task as task6 using a timer made by creating an object
//of class type CPolledTimer

void task8() {

	//creating an object "chasingLightTimer" of class type CPolledTimer with a
	//time delay of 1000ms

	CPolledTimer chasingLightTimer(1000);

	//initializing leds (first light is at furthest right side)

	leds = 1;

	while (true) {

		//If 1000ms has passed (timer has been reached)

		if (chasingLightTimer.timeReached()) {

			//LED is shifted by 1 to the left

			leds = leds << 1;

			//If LED has been shifted to the furthest left side

			if (leds == 0) {

				//LED is set to furthest right side

				leds = 1;
			}

		}
	}
}


//task9 creates a light path which is controllable with keys. The 4 furthest
//left leds represents the light path, and the 4 furthest right leds represent
//the binary worth of the lightVariable

void task9() {

	//creating an object "myDebouncer" of class type CDebouncer with a time
	//delay of 80ms

	CDebouncer myDebouncer(&keys, 80);

	//creating an object "chasingLightTimer" of class type CPolledTimer with
	//a default time delay of 1000ms

	CPolledTimer chasingLightTimer(1000);

	//reads the keys (before any key has been pressed) using the read() method
	//of class type CDebouncer

	uint8_t previousKeyStates = myDebouncer.read();

	//initiates the variable newKeyStates (which will be used to read pressed
	//keys)

	uint8_t newKeyStates = 0;

	//variable to control the light, which can take the value of -7....7

	uint8_t lightVariable = 0;

	//absolute value which represents the speed of light

	uint8_t lightSpeed = 0;

	//variable used to shift bits along the BusOut Object

	uint8_t shift = 0;

	//represents the direction of the chasing light

	bool toTheLeft = false;

	while (true) {

		//Is lightSpeed 0?

		if (lightSpeed == 0) {

//if so, then none of the lights run, and only the furthest right LED is
//turned on (they represent the binary worth of lightVariable = 8 [0b1000])

			leds.write((lightVariable<<4) & 0xF0);
		}

//If lightSpeed isn't 0...

		else {

//the 4 furthest left leds will run. Updates the 4 leds at the right
//side, also the 4 leds on the left according to "shift" variable

			leds.write(((1 << shift) & 0x0F)|((lightVariable<<4) & 0xF0));

//The code below checks if the target time in chasingLightTimer has been reached
//(1000ms) and also checks the direction of the light path and updates the shift
//variable accordingly

//If the timer has been reached...

			if (chasingLightTimer.timeReached()) {

//If the direction of light is to the right..

				if (toTheLeft==false) {

//If the light path has been shifted to the furthest right (0b0001 0000)

					if (shift >= 3) {

//shift variable is set to furthest possible right (0b0001 0000), in order to
//move the light path to the right later on

						shift = 0;

					}

//If not ...

					else {

//the shift variable will be updated to further move the light path to the right

						shift++;
					}

				}

//If the direction of light is to the left...

				else {

//If the light path has been shifted to the furthest left (0b1000 0000)

					if (shift == 0) {

//shift variable is set to furthest left (0b0001 0000), in order to
//move the light path to the left

						shift = 3;
					}

//the shift variable will be updated to further move the light path to the left

					else {
						shift--;
					}
				}
			}
		}

//The code below controls the buttons. Firstly the code checks if any of the
//buttons have been pressed since the previous loop, then checks which button
//was pressed and executes the corresponding task. At the end, lightSpeed and
//lightVariable are updated

		newKeyStates = myDebouncer.read();

//If any of the keys have been pressed

		if (newKeyStates != previousKeyStates) {

//updates previousKeyStates for the next iteration of the loop

			previousKeyStates = newKeyStates;

// If one of the direct-config-buttons is pressed, the control variable is
//updated (toggled)

			if (newKeyStates & 0xF0) {

				lightVariable ^= newKeyStates>>4;
				lightVariable &= 0x0F;

			}

//checks if the "+" button has been pressed (0b0001 0000)

			if (newKeyStates & 0x08) {

//If lightVariable isn't 7 (lightVariable would be added to 8)
//or lower than 15 (lightVariable would be added to 16, which is over our
//maximal absolute worth for lightVariable [-7...+7  ~  1...15])

				if (lightVariable <7||(lightVariable>8&&lightVariable<15)) {

//lightVariable is increased to increase speed and potentially the direction

					lightVariable++;

//value of lightVariable is always controlled so that it won't exceed 4 bits

					lightVariable &= 0x0F;

				}
			}

//checks if the "-" button has been pressed (0b0010 0000)

			if (newKeyStates & 0x04) {

//If lightVariable isn't 1 (lightVariable would be decreased to 0)
//or 9 (lightVariable would be decreased to 8 also considered to be 0)....

				if (lightVariable>9||(lightVariable<8&&lightVariable>1)) {

//lightVariable is decreased to decrease speed and potentially the direction

					lightVariable--;

					lightVariable &= 0x0F;

				}
			}

//checks if the "reverse" - button has been pressed (0b0100 0000)

			if (newKeyStates & 0x02) {

//If lightVariable is negative (has an "Most Significant Bit" [MSB] of 1)

				if (lightVariable & 0x08) {

//lightVariable is negated and added with 1 to be converted to positive, 0x0F
//is used to control the value of lightVariable so that it won't exceed 4 Bits

//The value of lightVariable is always controlled so that it won't exceed 4 bits

					lightVariable = (~lightVariable + 1) & 0x0F;
				}

//If lightVariable is positive (has an "Most Significant Bit" [MSB] of 0)

				else if (lightVariable & 0x07) {

//lightVariable is first subtracted by 1 and then negated to be converted to
//negative, 0x0F is used to control the value of lightVariable so that it won't
//exceed 4 Bits

					lightVariable = ~(lightVariable - 1) & 0x0F;
				}
			}

//the following code calculates the absolute speed from the control variable,
//and updates the chasingLightTimer with the updateWaitTime method

//If lightVariable is negative

						if (lightVariable & 0x08) {

//light path is moving to the left

							toTheLeft = true;

//If lightVariable takes the value of 0b1000

							if (lightVariable == 0x08) {

//lightSpeed is set to 0

								lightSpeed = 0;
							}

							else {

//reverts the lightVariable to positive by first negating the lightVariable
//and adding 1, also controls with "&0x0F" so that it won't exceed 4 bits
//and assigns the result to lightSpeed

								lightSpeed = (~lightVariable & 0x0F) + 1;
							}


						}

//If lightVariable isn't negative

						else {

//controls lightVariable with "&0x0F" so that it won't exceed 4 bits
//and assigns the result to lightSpeed

							lightSpeed = lightVariable & 0x0F;

//light path is moving to the right

							toTheLeft = false;
						}

//updates timer if a button has been pressed

						chasingLightTimer.updateWaitTime(lightSpeed * 250);
					}
		}
	}





// Legen Sie weitere Funktionen taskN() (mit N = 3, 4, 5, ...) nach Bedarf an.

/**
 * Haupt- oder Einstiegsfunktion des Programms. Wird beim Start nach der
 * Initialisierung der globalen Variablen (bei Objekten: Aufruf des
 * Konstruktors) ausgeführt.
 */
int main() {
	// Falls notwendig, ergänzen Sie hier Aufrufe, um Konfigurationen
	// an globalen Objekten vorzunehmen, die nicht durch die Angabe von
	// Argumenten beim Aufruf des Konstruktors vorgenommen werden können.

	// Aufruf der Funktion, die die Lösung der gerade bearbeiteten Aufgabe
	// implementiert.
	keys.mode(PullDown); //Objekt keys Initialisieren
	//task1();
	//task2();
	//task3();
//	task4();
//	task5();
//	task6();
//	task7();
//	task8();
	task9();



	/*
	 * Normalerweise endet der Aufruf einer der Funktionen task1(), task2(),
	 * etc. nie, d.h. der nachfolgende Code wird nie ausgeführt. Für den
	 * Fall, dass Ihnen bei der Implementierung einer der Funktionen ein
	 * Fehler unterläuft, ist hier "sicherheitshalber" noch mal eine
	 * Endlossschleife.
	 */
	while (true) {
	}
}
